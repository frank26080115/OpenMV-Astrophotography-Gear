#ifndef _PY_GUIDESTAR_H_
#define _PY_GUIDESTAR_H_

#include <mp.h>
#include "py/obj.h"
#include <stdint.h>
#include <stdbool.h>

extern const mp_obj_type_t   py_guidestar_type;
extern const mp_obj_module_t guidestar_module;

#endif
