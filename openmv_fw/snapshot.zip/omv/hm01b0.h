/*
 * This file is part of the OpenMV project.
 *
 * Copyright (c) 2013-2019 Ibrahim Abdelkader <iabdalkader@openmv.io>
 * Copyright (c) 2013-2019 Kwabena W. Agyeman <kwagyeman@openmv.io>
 *
 * This work is licensed under the MIT license, see the file LICENSE for details.
 *
 * HM01B0 driver.
 */
#ifndef __HM01B0_H__
#define __HM01B0_H__
#include "sensor.h"
int hm01b0_init(sensor_t *sensor);
#endif // __HM01B0_H__
